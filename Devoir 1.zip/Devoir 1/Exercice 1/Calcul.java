public class Calcul {

    public static void main(String[] args) {
        if (args.length != 3) {
            System.out.println("Veuillez entrez votre calcul de cette manière : java Calcul nombre1 opérateur nombre2 ");
            return;
        }

        int nombre1 = Integer.parseInt(args[0]);
        int nombre2 = Integer.parseInt(args[2]);
        char operateur = args[1].charAt(0);

        switch (operateur) {
            case '+':
                System.out.println(nombre1 + nombre2);
                break;
            case '-':
                System.out.println(nombre1 - nombre2);
                break;
            case '*':
                System.out.println(nombre1 * nombre2);
                break;
            case '/':
                if (nombre2 == 0) {
                    System.out.println("Division par zéro, veuillez changer de nombre");
                    break;
                }
                System.out.println(nombre1 / nombre2);
                break;
            default:
                System.out.println("L'opérateur est invalide");
        }
    }

}
