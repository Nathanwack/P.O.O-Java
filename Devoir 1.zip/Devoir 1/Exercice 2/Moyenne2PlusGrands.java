import java.util.Arrays;

public class Moyenne2PlusGrands {
    public static void main(String[] args) {
        double[] tableau = new double[args.length];
        for (int i = 0; i < args.length; i++) {
            tableau[i] = Double.parseDouble(args[i]);
        }
        double moyenne = calculerMoyenne2PlusGrands(tableau);
        System.out.println(moyenne);
    }

    public static double calculerMoyenne2PlusGrands(double[] tableau) {

        double[] tableauCopie = tableau.clone();
        Arrays.sort(tableauCopie);

        double somme = tableauCopie[tableauCopie.length - 1] + tableauCopie[tableauCopie.length - 2];
        return somme / 2;
    }
}
