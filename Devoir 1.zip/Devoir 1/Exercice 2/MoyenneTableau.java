public class MoyenneTableau {
    public static void main(String[] args) {
        double[] tableau = new double[args.length];
        for (int i = 0; i < args.length; i++) {
            tableau[i] = Double.parseDouble(args[i]);
        }
        double moyenne = calculerMoyenne(tableau);
        System.out.println(moyenne);
    }

    public static double calculerMoyenne(double[] tableau) {
        double somme = 0;
        for (double nombre : tableau) {
            somme += nombre;
        }

        return somme / tableau.length;
    }
}
