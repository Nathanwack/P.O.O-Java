public class Moyenne {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: java Moyenne <nombre1> <nombre2> ... <nombreN>");
            return;
        }

        double somme = 0;
        for (String arg : args) {
            double nombre = Double.parseDouble(arg);
            somme += nombre;
        }

        double moyenne = somme / args.length;
        System.out.println(moyenne);
    }
}
