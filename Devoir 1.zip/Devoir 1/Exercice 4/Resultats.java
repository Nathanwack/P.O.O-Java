public class Resultats {
    public static void main(String[] args) {
        Examen examen = new Examen();
        examen.ajoute(new Note("Alice", 12.5));
        examen.ajoute(new Note("Bob", 10.0));
        examen.ajoute(new Note("Charlie", 14.0));

        System.out.println("Moyenne : " + examen.moyenne());
        examen.resultats();
    }
}
