import java.util.ArrayList;

public class Examen {
    private ArrayList<Note> notes;

    public Examen() {
        notes = new ArrayList<>();
    }

    public void ajoute(Note note) {
        notes.add(note);
    }

    public double moyenne() {
        double total = 0;
        for (Note note : notes) {
            total += note.getNote();
        }
        return total / notes.size();
    }

    public void resultats() {
        for (Note note : notes) {
            note.affiche();
        }
    }
}
