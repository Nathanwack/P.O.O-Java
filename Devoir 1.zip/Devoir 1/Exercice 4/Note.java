public class Note {
    private String etudiant;
    private double note;

    public Note(String etudiant, double note) {
        this.etudiant = etudiant;
        this.note = note;
    }

    public void affiche() {
        System.out.println(etudiant + " : " + note);
    }

    public double getNote() {
        return note;
    }
}
