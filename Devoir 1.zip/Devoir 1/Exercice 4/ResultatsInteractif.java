import java.util.Scanner;

public class ResultatsInteractif {
    public static void main(String[] args) {
        Examen examen = new Examen();
        Scanner scanner = new Scanner(System.in);
        String etudiant;
        double note;

        while (true) {
            System.out.print("Entrez le nom de l'étudiant (ou 'q' pour quitter) : ");
            etudiant = scanner.next();
            if (etudiant.equals("q")) {
                break;
            }

            System.out.print("Entrez la note de l'étudiant : ");
            note = scanner.nextDouble();
            examen.ajoute(new Note(etudiant, note));
        }

        System.out.println("Moyenne : " + examen.moyenne());
        examen.resultats();
    }
}
