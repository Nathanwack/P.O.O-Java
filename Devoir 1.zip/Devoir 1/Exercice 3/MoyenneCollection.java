import java.util.ArrayList;
import java.util.List;

public class MoyenneCollection {
    public static void main(String[] args) {
        List<Double> liste = new ArrayList<>();
        for (String arg : args) {
            double nombre = Double.parseDouble(arg);
            liste.add(nombre);
        }
        double moyenne = calculerMoyenne(liste);
        System.out.println(moyenne);
    }

    public static double calculerMoyenne(List<Double> liste) {
        double somme = 0;
        for (double nombre : liste) {
            somme += nombre;
        }

        return somme / liste.size();
    }
}
