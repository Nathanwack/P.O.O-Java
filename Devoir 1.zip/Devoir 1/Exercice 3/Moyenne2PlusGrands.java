import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Moyenne2PlusGrands {
    public static void main(String[] args) {
        List<Double> liste = new ArrayList<>();
        for (String arg : args) {
            double nombre = Double.parseDouble(arg);
            liste.add(nombre);
        }
        double moyenne = calculerMoyenne2PlusGrands(liste);
        System.out.println(moyenne);
    }

    public static double calculerMoyenne2PlusGrands(List<Double> liste) {

        Collections.sort(liste);

        double somme = liste.get(liste.size() - 1) + liste.get(liste.size() - 2);
        return somme / 2;
    }
}
